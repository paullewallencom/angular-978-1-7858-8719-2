## $5 Tech Unlocked 2021!
[Buy and download this product for only $5 on PacktPub.com](https://www.packtpub.com/)
-----
*The $5 campaign         runs from __December 15th 2020__ to __January 13th 2021.__*

# AngularJS-By-Example

####Code repository for [AngularJS by Example](https://www.packtpub.com/web-development/angularjs-example?utm_source=github&utm_medium=repository&utm_campaign=9781783553815), published by Packt Publishing


#####[PACKT Publishing](https://www.packtpub.com)

For running the code examples you will need a text editor (preferably an IDE) which you can use to create and edit HTML, CSS, and JavaScript files.
It will be ideal if you are connected to the Internet while working on the samples as some samples link to libraries available online. To work in offline mode, you need to download the libraries and change the reference in the samples.


####Additionally you can refer to the following books:
* [AngularJS Web Application Development Cookbook](https://www.packtpub.com/web-development/angularjs-web-application-development-cookbook?utm_source=github&utm_medium=repository&utm_campaign=9781783283354)
* [Mastering Web Application Development with AngularJS](https://www.packtpub.com/web-development/mastering-web-application-development-angularjs?utm_source=github&utm_medium=repository&utm_campaign=9781782161820)
* [Mastering AngularJS Directives](https://www.packtpub.com/application-development/mastering-angularjs-directives?utm_source=github&utm_medium=repository&utm_campaign=9781783981588)
